import { GoogleGenAI, Type } from "@google/genai";

/**
 * Service to handle communication with the external FPL intelligence webhook.
 */
export async function chatWithGemini(messages: any[]) {
  // Pointing to the absolute path at the root domain
  const WEBHOOK_URL = '/api/chat';
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const currentMessage = messages[messages.length - 1].content;

  try {
    const webhookResponse = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: currentMessage,
        history: messages.slice(0, -1),
        timestamp: new Date().toISOString()
      }),
    });

    if (!webhookResponse.ok) {
      throw new Error(`Webhook engine error: ${webhookResponse.status}`);
    }

    const engineData = await webhookResponse.json();

    const prompt = `
              Manager's Question: "${currentMessage}"
              
              Intelligence Data from Scouting Engine: 
              ${JSON.stringify(engineData, null, 2)}
              
              Task:
              As an elite FPL Scout, interpret this data and provide a natural language summary.
              
              Requirements:
              - Use high-quality Markdown (bolding, lists, tables).
              - NEVER show raw JSON or technical parameters like "statusCode" or internal IDs.
              - Be professional, insightful, and concise.
              - Format the response so it looks like a premium scouting report.
            `;

    const summarizerResult = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        systemInstruction: "You are a world-class FPL Scout. You translate raw engine data into beautiful, actionable Markdown scouting reports."
      }
    });

    return {
      text: summarizerResult.text || "I received data from the engine but was unable to generate a summary.",
      data: engineData
    };

  } catch (error) {
    console.error("FPL Scout Communication Error:", error);
    throw error;
  }
}

/**
 * Generates marketing variants based on selected scouting content.
 */
export async function generateMessageVariants(content: string, channel: 'Push' | 'Social' | 'Email') {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Scouting Data:
    "${content}"
    
    Instruction:
    Generate exactly 3 creative marketing message variants for the ${channel} channel.
    
    Channel Specs:
    - Push: High impact, urgent, maximum 150 characters.
    - Social: Engaging tone, includes emojis and hashtags like #FPL.
    - Email: Includes a compelling subject line and a structured body.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        systemInstruction: "You are a senior FPL content strategist. Return a JSON object with a 'variants' array containing exactly 3 objects. Each object must have 'label' and 'content' strings.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            variants: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING, description: "A creative label for this variant" },
                  content: { type: Type.STRING, description: "The message text" }
                },
                required: ["label", "content"]
              },
              minItems: 3,
              maxItems: 3
            }
          },
          required: ["variants"]
        }
      },
    });

    const rawText = response.text;
    if (!rawText) throw new Error("AI returned no text content");

    const jsonString = rawText.replace(/```json\n?|```/g, '').trim();
    const data = JSON.parse(jsonString);
    
    if (!data.variants || !Array.isArray(data.variants)) {
        throw new Error("Invalid response format: missing variants array");
    }

    return data.variants;
  } catch (error) {
    console.error("Variant generation failed, using fallbacks:", error);
    return [
      { 
        label: "Strategic Edge", 
        content: `🚨 **FPL SCOUT UPDATE**\n\nBased on the latest data, your squad needs an adjustment. Key assets are showing massive potential for GW${Math.floor(Math.random() * 38) + 1}. Check the reports now!` 
      },
      { 
        label: "Market Alert", 
        content: "Transfer window analysis complete. We've identified 3 budget-friendly differentials with low ownership and high xG. Don't fall behind the template. ⚽️ #FPL" 
      },
      { 
        label: "Elite Insight", 
        content: "Captaincy choice locked? Our engine suggests a surprising alternative to Haaland this week. Dive into the numbers before the deadline hits." 
      }
    ];
  }
}

/**
 * Generates 3 creative image options for a given message content.
 */
export async function generateCreativeOptions(messageContent: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Styles for the 3 variations
  const styles = [
    "hyper-realistic sports photography style, cinematic lighting, stadium background",
    "modern minimalist vector illustration style, vibrant emerald and indigo color palette",
    "futuristic data visualization overlay on a close-up football texture, neon accents"
  ];

  const generateSingleImage = async (style: string) => {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `Generate a high-quality visual for an FPL scouting app. Topic: ${messageContent}. Visual style: ${style}. No text in the image.` }]
      },
      config: {
        imageConfig: { aspectRatio: "1:1" }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  };

  try {
    const results = await Promise.all(styles.map(s => generateSingleImage(s)));
    return results.filter(img => img !== null) as string[];
  } catch (error) {
    console.error("Creative generation failed:", error);
    // Return high-quality generic fallbacks if generation fails
    return [
      "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1517466787929-bc90951d0974?auto=format&fit=crop&q=80&w=800"
    ];
  }
}
